/**
 * CargoAI - Global Maritime Ports & Vessel Fleet Database
 */

const PORTS_DB = [
    { id: 'SHA', name: 'Shanghai', country: 'China', code: 'CNSHA', lat: 31.2304, lng: 121.4737, maxDraft: 16.0, type: ['Container', 'Bulk', 'Project'] },
    { id: 'SGP', name: 'Singapore', country: 'Singapore', code: 'SGSGP', lat: 1.3521, lng: 103.8198, maxDraft: 18.0, type: ['Container', 'Bulk', 'Ro-Ro', 'Project'] },
    { id: 'RTM', name: 'Rotterdam', country: 'Netherlands', code: 'NLRTM', lat: 51.9244, lng: 4.4777, maxDraft: 22.5, type: ['Container', 'Bulk', 'Ro-Ro', 'Project'] },
    { id: 'HAM', name: 'Hamburg', country: 'Germany', code: 'DEHAM', lat: 53.5511, lng: 9.9937, maxDraft: 15.1, type: ['Container', 'Project', 'Ro-Ro'] },
    { id: 'HOU', name: 'Houston', country: 'United States', code: 'USHOU', lat: 29.7604, lng: -95.3698, maxDraft: 14.5, type: ['Container', 'Bulk', 'Project'] },
    { id: 'LAX', name: 'Los Angeles', country: 'United States', code: 'USLAX', lat: 33.7420, lng: -118.2700, maxDraft: 16.2, type: ['Container', 'Ro-Ro'] },
    { id: 'QIN', name: 'Qingdao', country: 'China', code: 'CNQIN', lat: 36.0671, lng: 120.3826, maxDraft: 20.0, type: ['Bulk', 'Container'] },
    { id: 'RTN', name: 'Ras Tanura', country: 'Saudi Arabia', code: 'SARTN', lat: 26.6450, lng: 50.1580, maxDraft: 21.0, type: ['Bulk', 'Tanker'] },
    { id: 'HED', name: 'Port Hedland', country: 'Australia', code: 'AUPHE', lat: -20.3107, lng: 118.5753, maxDraft: 19.5, type: ['Bulk'] },
    { id: 'DXB', name: 'Jebel Ali (Dubai)', country: 'UAE', code: 'AEJEA', lat: 24.9857, lng: 55.0664, maxDraft: 17.0, type: ['Container', 'Ro-Ro', 'Project'] },
    { id: 'SAN', name: 'Santos', country: 'Brazil', code: 'BRSSZ', lat: -23.9608, lng: -46.3339, maxDraft: 14.2, type: ['Bulk', 'Container'] },
    { id: 'SYD', name: 'Sydney (Port Botany)', country: 'Australia', code: 'AUSYD', lat: -33.8688, lng: 151.2093, maxDraft: 14.0, type: ['Container', 'Ro-Ro'] },
    { id: 'CPT', name: 'Cape Town', country: 'South Africa', code: 'ZACPT', lat: -33.9249, lng: 18.4241, maxDraft: 15.5, type: ['Container', 'Project'] }
];

const VESSEL_TYPES = [
    {
        id: 'heavy_lift',
        name: 'Heavy-Lift / Project Cargo Vessel',
        category: 'Heavy-Lift / Project Cargo Vessel',
        maxWeightCapacityTonnes: 3000,
        maxDeckAreaSqM: 4500,
        maxSingleCraneLiftTonnes: 1200,
        maxCraneReachMetres: 28,
        draftMetres: 8.5,
        speedKnots: 14.0,
        dailyCharterRateUSD: 32000,
        fuelConsTonPerDay: 25,
        suitableCargoTypes: ['Heavy Machinery / Transformers', 'Industrial Wind Turbines', 'Breakbulk & Oversized', 'Project Equipment'],
        description: 'Specialized heavy-lift vessel equipped with twin high-capacity 600T deck cranes (1,200T tandem lift capacity) and reinforced heavy hatch covers.'
    },
    {
        id: 'roro_vessel',
        name: 'Ro-Ro (Roll-on / Roll-off) Vessel',
        category: 'Ro-Ro Vessel',
        maxWeightCapacityTonnes: 15000,
        maxDeckAreaSqM: 18000,
        maxRampCapacityTonnes: 350,
        maxHeightClearanceMetres: 6.8,
        draftMetres: 9.8,
        speedKnots: 16.5,
        dailyCharterRateUSD: 27500,
        fuelConsTonPerDay: 32,
        suitableCargoTypes: ['Wheeled Vehicles & Excavators', 'Rolling Heavy Machinery', 'Rail Cars & Trailers'],
        description: 'Purpose-built vehicle and rolling cargo carrier featuring stern ramps rated up to 350 tonnes and adjustable deck height clearances.'
    },
    {
        id: 'container_ship',
        name: 'Panamax Container Ship',
        category: 'Container Ship',
        maxWeightCapacityTonnes: 52000,
        maxTEU: 4500,
        maxSingleCraneLiftTonnes: 45, // Container cranes
        draftMetres: 13.5,
        speedKnots: 18.0,
        dailyCharterRateUSD: 24000,
        fuelConsTonPerDay: 48,
        suitableCargoTypes: ['Standard Containerized Cargo', 'Refrigerated Goods (Reefer)', 'Hazardous IMO Chemicals', 'Palletized Freight'],
        description: 'Standard multi-purpose cellular container vessel optimized for ISO 20ft/40ft containers, flat racks, and open-top containers.'
    },
    {
        id: 'bulk_carrier',
        name: 'Supramax / Panamax Bulk Carrier',
        category: 'Bulk Carrier',
        maxWeightCapacityTonnes: 75000,
        holdVolumeCBM: 90000,
        draftMetres: 14.2,
        speedKnots: 13.5,
        dailyCharterRateUSD: 19500,
        fuelConsTonPerDay: 28,
        suitableCargoTypes: ['Dry Bulk (Grain/Coal/Iron Ore)', 'Mineral Concentrates', 'Raw Materials'],
        description: 'Large single-deck bulk freighter designed for unpackaged dry commodities, equipped with grab cranes and automated hatch covers.'
    }
];

// Export to window scope for SPA availability
if (typeof window !== 'undefined') {
    window.PORTS_DB = PORTS_DB;
    window.VESSEL_TYPES = VESSEL_TYPES;
}
