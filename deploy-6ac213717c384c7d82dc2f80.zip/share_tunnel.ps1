# Auto-reconnecting SSH Tunnel script for CargoAI
while ($true) {
    Write-Host "Starting CargoAI public tunnel..."
    ssh -o ServerAliveInterval=15 -o ServerAliveCountMax=3 -o StrictHostKeyChecking=no -R 80:localhost:8080 serveo.net
    Write-Host "Tunnel disconnected. Reconnecting in 5 seconds..."
    Start-Sleep -Seconds 5
}
