/**
 * CargoAI - Decoupled AI Recommendation & Logistics Engine
 * 
 * Analyzes cargo specifications, classifies cargo, computes vessel suitability scores,
 * optimizes sea routes, calculates detailed cost/transit time estimates, and evaluates AI safety guardrails.
 */

class CargoAIEngine {
    constructor() {
        this.ports = window.PORTS_DB || [];
        this.vesselTypes = window.VESSEL_TYPES || [];
    }

    /**
     * 1. Validate Input Parameters
     */
    validateCargo(cargo) {
        const errors = [];
        if (!cargo.name || cargo.name.trim() === '') errors.push("Cargo name is required.");
        if (!cargo.weightTonnes || cargo.weightTonnes <= 0) errors.push("Weight must be greater than 0 tonnes.");
        if (!cargo.lengthMetres || cargo.lengthMetres <= 0) errors.push("Length must be greater than 0 metres.");
        if (!cargo.widthMetres || cargo.widthMetres <= 0) errors.push("Width must be greater than 0 metres.");
        if (!cargo.heightMetres || cargo.heightMetres <= 0) errors.push("Height must be greater than 0 metres.");
        if (!cargo.originPort) errors.push("Origin port (POL) is required.");
        if (!cargo.destinationPort) errors.push("Destination port (POD) is required.");
        if (cargo.originPort === cargo.destinationPort) errors.push("Origin and destination ports cannot be the same.");

        return {
            isValid: errors.length === 0,
            errors
        };
    }

    /**
     * 2. AI Cargo Classification
     */
    classifyCargo(cargo) {
        const weight = Number(cargo.weightTonnes);
        const length = Number(cargo.lengthMetres);
        const width = Number(cargo.widthMetres);
        const height = Number(cargo.heightMetres);
        const volumeCBM = cargo.volumeCBM || (length * width * height);

        // Determine Weight Category
        let weightCategory = "Standard Weight (< 50t)";
        if (weight > 500) weightCategory = "Ultra-Heavy Lift (> 500t)";
        else if (weight > 100) weightCategory = "Heavy Cargo (100t - 500t)";
        else if (weight > 50) weightCategory = "Medium Heavy Cargo (50t - 100t)";

        // Determine Size Category
        const isISOContainerSize = length <= 12.2 && width <= 2.44 && height <= 2.59;
        let sizeCategory = "Standard ISO Dimension";
        if (length > 15 || width > 4.5 || height > 4.0) {
            sizeCategory = "Out-of-Gauge (OOG) Massive Breakbulk";
        } else if (!isISOContainerSize) {
            sizeCategory = "Oversized Project Cargo";
        }

        // Determine Handling Requirement
        const handlingReqs = [];
        if (cargo.specialHandling && cargo.specialHandling !== 'None') {
            handlingReqs.push(cargo.specialHandling);
        }
        if (weight > 100) {
            handlingReqs.push("Dual Tandem Heavy-Lift Crane Deployment");
        }
        if (cargo.isFragile) {
            handlingReqs.push("Vibration-Dampened Deck Stowage & Lashing");
        }
        if (cargo.isHazardous) {
            handlingReqs.push("IMO Dangerous Goods Hazardous Containment Protocol");
        }
        if (cargo.cargoType === 'Wheeled Vehicles & Excavators') {
            handlingReqs.push("Roll-On Roll-Off Ramp Clearance & Wheel Securing");
        }

        // Determine Cargo Classification & Recommended Category
        let classification = "Standard General Freight";
        let recommendedCategory = "Container Ship";
        let explanation = "";

        if (cargo.cargoType === 'Wheeled Vehicles & Excavators' || cargo.cargoType === 'Rolling Machinery') {
            classification = "Ro-Ro Heavy Wheeled Cargo";
            recommendedCategory = "Ro-Ro Vessel";
            explanation = "Cargo consists of self-propelled or towable wheeled machinery requiring ramp loading rather than crane lifting.";
        } else if (weight > 100 || length > 12.5 || width > 3.5 || height > 3.5) {
            classification = "Heavy Project Cargo";
            recommendedCategory = "Heavy-Lift / Project Cargo Vessel";
            explanation = `Cargo weight (${weight}t) or oversized dimensions (${length}m x ${width}m x ${height}m) exceed standard container dimensions, requiring heavy crane capacity and reinforced deck space.`;
        } else if (cargo.cargoType === 'Dry Bulk (Grain/Coal/Iron Ore)') {
            classification = "Unpackaged Dry Bulk";
            recommendedCategory = "Bulk Carrier";
            explanation = "Cargo is loose bulk material best transported in bulk holds with automated grab cranes.";
        } else {
            classification = "Standard Containerized Freight";
            recommendedCategory = "Container Ship";
            explanation = "Cargo fits safely within standard ISO 20ft/40ft container envelopes or flat-rack containers.";
        }

        return {
            classification,
            weightCategory,
            sizeCategory,
            volumeCBM: Math.round(volumeCBM),
            handlingRequirements: handlingReqs.length > 0 ? handlingReqs : ["Standard Port Cargo Handling"],
            recommendedCategory,
            explanation
        };
    }

    /**
     * 3. Vessel Suitability Evaluation
     */
    evaluateVessels(cargo, classificationInfo) {
        const weight = Number(cargo.weightTonnes);
        const length = Number(cargo.lengthMetres);
        const width = Number(cargo.widthMetres);
        const height = Number(cargo.heightMetres);

        const results = this.vesselTypes.map(vessel => {
            let score = 100;
            const disqualifications = [];
            const advantages = [];

            // GUARDRAIL: Strict Capacity Check
            if (weight > vessel.maxWeightCapacityTonnes) {
                disqualifications.push(`Cargo weight (${weight}t) exceeds vessel max deadweight capacity (${vessel.maxWeightCapacityTonnes}t).`);
                score = 0;
            }

            // Category match scoring
            if (vessel.category === classificationInfo.recommendedCategory) {
                advantages.push(`Perfect category match for ${classificationInfo.classification}.`);
                score += 15;
            } else {
                score -= 30;
            }

            // Crane capability check for Heavy Lift
            if (weight > 50 && vessel.maxSingleCraneLiftTonnes) {
                if (weight > vessel.maxSingleCraneLiftTonnes * 2) {
                    disqualifications.push(`Cargo weight (${weight}t) exceeds vessel max crane tandem lift capacity (${vessel.maxSingleCraneLiftTonnes * 2}t).`);
                    score = 0;
                } else {
                    advantages.push(`Equipped with ${vessel.maxSingleCraneLiftTonnes}T crane for self-sustained loading.`);
                }
            } else if (weight > 50 && !vessel.maxSingleCraneLiftTonnes) {
                if (vessel.category !== 'Ro-Ro Vessel') {
                    score -= 25;
                    disqualifications.push("Vessel lacks onboard heavy cranes; requires shore crane support.");
                }
            }

            // Ro-Ro Height Clearance Check
            if (vessel.category === 'Ro-Ro Vessel') {
                if (height > vessel.maxHeightClearanceMetres) {
                    disqualifications.push(`Cargo height (${height}m) exceeds Ro-Ro deck clearance (${vessel.maxHeightClearanceMetres}m).`);
                    score = 0;
                } else if (cargo.cargoType === 'Wheeled Vehicles & Excavators') {
                    score += 20;
                    advantages.push("Allows fast roll-on drive loading without crane risks.");
                }
            }

            // Final score clamping
            if (disqualifications.length > 0) {
                score = 0;
            } else {
                score = Math.min(99, Math.max(35, score));
            }

            return {
                vessel,
                suitabilityScore: score,
                isRecommended: false,
                isEligible: disqualifications.length === 0,
                disqualifications,
                advantages,
                approxCapacity: `${vessel.maxWeightCapacityTonnes.toLocaleString()} Tonnes`,
                cargoCompatibility: disqualifications.length === 0 ? "High Compatibility" : "Incompatible"
            };
        });

        // Filter and sort
        const eligible = results.filter(r => r.isEligible).sort((a, b) => b.suitabilityScore - a.suitabilityScore);
        
        if (eligible.length > 0) {
            eligible[0].isRecommended = true;
        }

        return {
            allEvaluations: results,
            topRecommendations: eligible,
            bestRecommendation: eligible[0] || null
        };
    }

    /**
     * 4. Route & Transit Time Calculation
     */
    calculateRoute(originPortId, destPortId, vessel) {
        const origin = this.ports.find(p => p.id === originPortId) || this.ports[0];
        const dest = this.ports.find(p => p.id === destPortId) || this.ports[1];

        // Haversine distance in Nautical Miles
        const R = 3440.065;
        const dLat = (dest.lat - origin.lat) * Math.PI / 180;
        const dLon = (dest.lng - origin.lng) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(origin.lat * Math.PI / 180) * Math.cos(dest.lat * Math.PI / 180) *
                  Math.sin(dLon/2) * Math.sin(dLon/2);
        const directNM = R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)));

        // Determine realistic sea lane intermediate waypoints & chokepoints
        const majorStops = [origin.name];
        let viaSuez = false;
        let viaPanama = false;
        let routeName = "Direct Oceanic Shipping Lane";

        if ((origin.id === 'HAM' || origin.id === 'RTM') && (dest.id === 'SGP' || dest.id === 'SHA' || dest.id === 'DXB')) {
            routeName = "Europe - Asia Suez Canal Sea Route";
            majorStops.push("Strait of Gibraltar", "Suez Canal (Egypt)", "Bab-el-Mandeb", "Strait of Malacca");
            viaSuez = true;
        } else if ((origin.id === 'SHA' || origin.id === 'SGP') && (dest.id === 'HOU' || dest.id === 'SAN')) {
            routeName = "Trans-Pacific Panama Canal Route";
            majorStops.push("East China Sea", "Panama Canal (Panama)", "Gulf of Mexico");
            viaPanama = true;
        } else if (origin.id === 'HED' && dest.id === 'QIN') {
            routeName = "Australia - China Iron Ore Direct Lane";
            majorStops.push("Lombok Strait", "South China Sea");
        } else {
            majorStops.push("International Deep Water Sea Corridor");
        }
        majorStops.push(dest.name);

        const totalNM = Math.round(directNM * 1.15); // +15% margin for sea navigation
        const speedKts = vessel ? vessel.speedKnots : 14.0;
        const steamingDays = totalNM / (speedKts * 24);
        const loadingDischargeDays = 3.0; // 1.5 days POL + 1.5 days POD
        const totalTransitDays = Math.ceil(steamingDays + loadingDischargeDays);

        return {
            origin,
            destination: dest,
            routeName,
            distanceNM: totalNM,
            distanceKm: Math.round(totalNM * 1.852),
            speedKnots: speedKts,
            steamingDays: steamingDays.toFixed(1),
            portHandlingDays: loadingDischargeDays,
            estimatedTransitDays: totalTransitDays,
            majorStops,
            viaSuez,
            viaPanama,
            routeScore: 94 // High reliability score
        };
    }

    /**
     * 5. Cost Estimation Breakdown
     */
    calculateCosts(cargo, vessel, routeInfo) {
        if (!vessel) return null;

        const charterDays = Math.ceil(Number(routeInfo.steamingDays) + 3); // Includes positioning margin
        const vesselFreightCost = charterDays * vessel.dailyCharterRateUSD;

        const fuelConsDay = vessel.fuelConsTonPerDay;
        const totalFuelTons = fuelConsDay * Number(routeInfo.steamingDays);
        const vlsfoPriceUSD = 650; // $650 per Tonne VLSFO
        const fuelCost = totalFuelTons * vlsfoPriceUSD;

        const portHandlingCost = 45000 + (cargo.weightTonnes * 18);
        
        let specialHandlingCost = 0;
        if (cargo.weightTonnes > 100) specialHandlingCost += 35000; // Dual Crane Mobilization
        if (cargo.isHazardous) specialHandlingCost += 22000; // IMO Safety Escort
        if (cargo.isFragile) specialHandlingCost += 12000; // Lashing Certification

        const totalCost = vesselFreightCost + fuelCost + portHandlingCost + specialHandlingCost;
        const costPerTonne = totalCost / cargo.weightTonnes;

        return {
            vesselFreightEstimate: Math.round(vesselFreightCost),
            fuelLogisticsEstimate: Math.round(fuelCost),
            portHandlingEstimate: Math.round(portHandlingCost),
            specialHandlingEstimate: Math.round(specialHandlingCost),
            totalEstimatedCost: Math.round(totalCost),
            costPerTonne: costPerTonne.toFixed(2),
            charterDays
        };
    }

    /**
     * 6. AI Safety & Guardrails Verification
     */
    evaluateSafetyGuardrails(cargo, vesselEval, routeInfo) {
        const warnings = [];
        let confidenceScore = 96;

        // Check 1: Vessel Capacity
        if (!vesselEval || !vesselEval.isEligible) {
            warnings.push("WARNING: Selected vessel is ineligible or exceeds capacity thresholds.");
            confidenceScore -= 40;
        }

        // Check 2: Hazardous Goods
        if (cargo.isHazardous) {
            warnings.push("HAZMAT ALERT: Cargo contains IMO Hazardous materials. Port clearance & DG declaration mandatory prior to loading.");
            confidenceScore -= 5;
        }

        // Check 3: Ultra Heavy Lift Crane Warning
        if (cargo.weightTonnes > 300) {
            warnings.push("HEAVY LIFT ALERT: Weight > 300 tonnes requires tandem crane lifting certification & deck load density verification.");
            confidenceScore -= 8;
        }

        // Check 4: Draft Safety Margins
        if (vesselEval && vesselEval.vessel) {
            const vesselDraft = vesselEval.vessel.draftMetres;
            if (vesselDraft > routeInfo.origin.maxDraft || vesselDraft > routeInfo.destination.maxDraft) {
                warnings.push(`DRAFT DEFICIT: Vessel draft (${vesselDraft}m) exceeds available depth at target port. High risk of grounding.`);
                confidenceScore -= 35;
            }
        }

        const isLowConfidence = confidenceScore < 70;
        const confidenceLabel = isLowConfidence 
            ? "AI confidence is low. Human logistics verification is recommended." 
            : "High AI Confidence - Parameters Verified against Maritime Standards";

        return {
            confidenceScore,
            isLowConfidence,
            confidenceLabel,
            warnings
        };
    }

    /**
     * 7. Generate Natural Language AI Decision Explanation
     */
    generateExplanation(cargo, classificationInfo, vesselEval, routeInfo, costInfo) {
        if (!vesselEval || !vesselEval.vessel) {
            return "No compatible vessel could be recommended due to extreme capacity or dimension restrictions. Manual chartering review required.";
        }

        const vessel = vesselEval.vessel;
        return `AI recommended the ${vessel.name} because its heavy deadweight capacity (${vessel.maxWeightCapacityTonnes.toLocaleString()} tonnes) comfortably exceeds the required ${cargo.weightTonnes} tonnes payload with a high safety factor. Furthermore, the vessel's ${classificationInfo.sizeCategory} capability satisfies all dimensional parameters (${cargo.lengthMetres}m L x ${cargo.widthMetres}m W x ${cargo.heightMetres}m H). For the ${routeInfo.origin.name} to ${routeInfo.destination.name} voyage (${routeInfo.distanceNM.toLocaleString()} NM), this option delivers an optimal balance of an estimated ${routeInfo.estimatedTransitDays} days transit time and $${costInfo.totalEstimatedCost.toLocaleString()} total cost ($${costInfo.costPerTonne}/tonne).`;
    }

    /**
     * Complete Full Pipeline Execution
     */
    analyze(cargo) {
        const validation = this.validateCargo(cargo);
        if (!validation.isValid) {
            return { isValid: false, errors: validation.errors };
        }

        const classification = this.classifyCargo(cargo);
        const vesselEvaluations = this.evaluateVessels(cargo, classification);
        const bestVesselEval = vesselEvaluations.bestRecommendation;

        const routeInfo = this.calculateRoute(cargo.originPort, cargo.destinationPort, bestVesselEval ? bestVesselEval.vessel : null);
        const costInfo = this.calculateCosts(cargo, bestVesselEval ? bestVesselEval.vessel : null, routeInfo);
        const safetyInfo = this.evaluateSafetyGuardrails(cargo, bestVesselEval, routeInfo);
        const explanation = this.generateExplanation(cargo, classification, bestVesselEval, routeInfo, costInfo);

        return {
            isValid: true,
            cargo,
            classification,
            vesselEvaluations,
            bestVesselEval,
            routeInfo,
            costInfo,
            safetyInfo,
            explanation
        };
    }
}

if (typeof window !== 'undefined') {
    window.CargoAIEngine = CargoAIEngine;
}
