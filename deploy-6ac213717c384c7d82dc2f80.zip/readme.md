# CargoAI — AI-Powered Maritime Cargo Transportation Decision-Support Platform

**CargoAI** is a professional, responsive decision-support platform designed for maritime cargo owners, project freight forwarders, and logistics operators. It analyzes cargo specifications and provides real-time AI recommendations for suitable vessel types, sea routing pathways, cost estimations, transit duration, and safety/guardrail compliance checks.

---

## 🌟 Key Features & Requirements Checklist

### 1. **Page 1 — Cargo Input & Specifications**
- Comprehensive cargo input form with real-time field validation.
- Fields: Cargo Name, Cargo Type, Weight (Tonnes), Length/Width/Height (Metres), Auto-calculated Volume ($M^3$), Origin Port (POL), Destination Port (POD), Special Handling Requirements, Fragile & Hazardous toggles.
- **"Analyze Cargo with AI"** interactive workflow trigger.
- **Demo Presets**: 1-click loading for 800t Industrial Gas Turbine, 350t Heavy Excavator Fleet, 65,000t Grain Bulk, and 1,200t Hazmat Chemical Drums.

### 2. **Page 2 — AI Cargo Classification & Assessment**
- Structural payload analysis: Weight Category (Standard, Medium, Heavy, Ultra-Heavy Lift > 500t), Size Category (Standard ISO, Out-of-Gauge OOG), Handling Requirements (Tandem Dual Crane Lift, Temperature Control, Ramp Ro-Ro), and Recommended Category.
- Transparent natural language explanation of cargo classification rationale.

### 3. **Page 3 — Vessel Matching & Suitability Ranking**
- Evaluation of candidate vessel categories:
  - **Heavy-Lift / Project Cargo Vessel** (Twin 600T deck cranes, 1,200T tandem lift capacity)
  - **Ro-Ro (Roll-on / Roll-off) Vessel** (350T stern ramp capacity)
  - **Panamax Container Ship** (4,500 TEU capacity)
  - **Supramax / Panamax Bulk Carrier** (75,000 Tonnes bulk capacity)
- Best recommendation highlighted with Suitability Score (0-100%).
- Strict capacity guardrails: Automatically disqualifies ineligible vessels whose deadweight or crane capacity is insufficient.

### 4. **Page 4 — Maritime Route Optimization & Waypoints**
- Calculates nautical miles distance, estimated transit time, steaming speed, and major passage chokepoints (e.g. Strait of Gibraltar, Suez Canal, Bab-el-Mandeb, Strait of Malacca, Panama Canal).
- **Interactive Leaflet Maritime Map**: Visualizes origin/destination ports, waypoints, and animated sea route line.
- Labeled simulated maritime data indicator.

### 5. **Page 5 — Cost Breakdown & Comparison**
- Granular expense breakdown: Vessel Charter Freight, Bunker Fuel Consumption ($650/Tonne VLSFO), Port Dues & Terminal Handling, Special Crane/IMO Escort Surcharges, Total Estimated Cost, and Cost per Tonne.
- Side-by-side comparative matrix of top vessel options.
- Labeled estimated demo values.

### 6. **Page 6 — AI Decision Explanation & Safety Guardrails**
- **"Why did AI recommend this?"** transparent explanation.
- **AI Safety / Guardrails Checker**:
  - Validates draft margins against target ports.
  - Checks crane tandem lift safety threshold for payloads > 300t.
  - Flags IMO Hazardous Goods declaration requirements.
  - Automatically triggers warning banner: **"AI confidence is low. Human logistics verification is recommended."** if draft or capacity limits are breached.

### 7. **Consolidated Executive Dashboard View**
- All-in-one executive overview combining cargo stats, AI classification, top vessel choice, route transit stats, cost breakdown, option matrix, and safety compliance status.

---

## 🏗️ Architecture & Project Structure

```
cargo_ai/
├── index.html            # Main single-page web application & UI views
├── js/
│   ├── cargoEngine.js    # Decoupled AI classification, vessel matching, & routing logic
│   └── vesselDatabase.js # Global ports database (POL/POD) & vessel fleet catalogs
└── README.md             # Documentation & setup instructions
```

### Decoupled Logic Architecture:
The core recommendation algorithm is strictly decoupled in `js/cargoEngine.js` via the `CargoAIEngine` class. This allows the AI engine to be easily connected to live REST APIs, LLM endpoints, or maritime AIS tracking services without modifying the frontend UI logic.

---

## 🚀 How to Run the Application

Because CargoAI is built using modern web standards (React-style declarative UI, Tailwind CSS, Leaflet.js, and Lucide icons), **it runs instantly in any web browser without needing `npm install` or node servers**.

### Option A: Open Directly in Browser
Double-click `index.html` or open `C:\Users\akank\.gemini\antigravity\scratch\cargo_ai\index.html` directly in Chrome, Edge, Firefox, or Safari.

### Option B: Local Web Server
You can also serve it using Python's built-in HTTP server:
```bash
cd C:\Users\akank\.gemini\antigravity\scratch\cargo_ai
python -m http.server 8080
```
Then open `http://localhost:8080` in your web browser.

---

## 💡 Setting Active Workspace Recommendation

To work with this project directly, set the active workspace in Antigravity to:
`C:\Users\akank\.gemini\antigravity\scratch\cargo_ai`
